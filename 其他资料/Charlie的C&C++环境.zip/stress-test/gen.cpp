#include <iostream>
#include <random>
#define endl '\n'
using namespace std;
using ll = long long;

mt19937 gen(random_device{}());

/* 生成 [l, r] 的随机整数 */
ll randint(ll l, ll r) { return uniform_int_distribution<ll>(l, r)(gen); }

int main() {
  cin.tie(nullptr)->sync_with_stdio(false);

  const ll n = 8;
  cout << n << endl;
  for (int i = 1; i <= n; i++) {
    cout << randint(0, 1) << " ";
  }
}
