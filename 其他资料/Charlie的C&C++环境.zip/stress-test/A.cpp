#include <iostream>
using namespace std;

int n;
bool ans = true;

int main() {
  cin >> n;
  while (n--) {
    int temp;
    cin >> temp;
    ans *= temp;
  }
  cout << ans;
}
