#include <stdio.h>
#define f(i, a, b) for (ll i = (a), _N_##i = (b); i <= _N_##i; i++)
#define fr(i, a, b) for (ll i = (a), _N_##i = (b); i >= _N_##i; i--)
#define endl '\n'
#define ll long long
const ll N = 2e5 + 7, INF = 1145141919810114514;

int main() {
  printf("Hello, World from C!\n");
}
