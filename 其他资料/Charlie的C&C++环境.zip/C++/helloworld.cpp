#include <iostream>
#define f(i, a, b) for (ll i = (a), _N_##i = (b); i <= _N_##i; i++)
#define fr(i, a, b) for (ll i = (a), _N_##i = (b); i >= _N_##i; i--)
#define endl '\n'
using namespace std;
using ll = long long;
using Pair = pair<ll, ll>;
const ll N = 2e5 + 7, INF = 114514'1919810'114514;

int main() {
  cout << "Hello, World from C++!" << endl;
}
